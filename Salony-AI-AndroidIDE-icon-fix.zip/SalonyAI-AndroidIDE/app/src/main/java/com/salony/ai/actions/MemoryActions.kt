package com.salony.ai.actions

import android.content.Context
import com.salony.ai.data.MemoryRepository
import com.salony.ai.model.ActionResult

class SaveMemoryAction(private val repository: MemoryRepository) : DeviceAction {
    override val name: String = "saveMemory"
    override val description: String = "Saves user personal details, preferences, projects, goals, or facts to persistent storage."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val key = (args["key"] as? String)?.trim()
            ?: return ActionResult(false, "Key or topic is required", name)
        val content = (args["content"] as? String)?.trim()
            ?: return ActionResult(false, "Memory content is required", name)
        val category = (args["category"] as? String) ?: "general"

        val item = repository.save(key, content, category)
        return ActionResult(
            success = true,
            message = "Saved to memory: \"${item.key}\"",
            actionName = name,
            details = mapOf("id" to item.id, "key" to item.key, "content" to item.content)
        )
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "key" to mapOf("type" to "STRING", "description" to "Topic or title of memory"),
                    "content" to mapOf("type" to "STRING", "description" to "Exact information to remember"),
                    "category" to mapOf(
                        "type" to "STRING",
                        "description" to "Category: personal, preferences, projects, goals, general",
                        "enum" to listOf("personal", "preferences", "projects", "goals", "general")
                    )
                ),
                "required" to listOf("key", "content")
            )
        )
    }
}

class SearchMemoriesAction(private val repository: MemoryRepository) : DeviceAction {
    override val name: String = "searchMemories"
    override val description: String = "Searches persistent memories about user preferences, name, projects, etc."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val query = (args["query"] as? String)?.trim() ?: ""
        val category = args["category"] as? String

        val results = repository.search(query, category)
        val summary = if (results.isNotEmpty()) {
            results.joinToString("; ") { "${it.key}: ${it.content}" }
        } else {
            "No matching memories found."
        }

        return ActionResult(
            success = true,
            message = summary,
            actionName = name,
            details = mapOf("count" to results.size, "results" to results)
        )
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "query" to mapOf("type" to "STRING", "description" to "Keyword to search for"),
                    "category" to mapOf("type" to "STRING", "description" to "Optional category filter")
                ),
                "required" to listOf("query")
            )
        )
    }
}

class ListMemoriesAction(private val repository: MemoryRepository) : DeviceAction {
    override val name: String = "listMemories"
    override val description: String = "Lists all stored memories or memories in a specific category."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val category = args["category"] as? String
        val list = repository.search(null, category)
        val summary = if (list.isNotEmpty()) {
            list.joinToString("; ") { "${it.key}: ${it.content}" }
        } else {
            "No memories saved yet."
        }

        return ActionResult(
            success = true,
            message = summary,
            actionName = name,
            details = mapOf("count" to list.size)
        )
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "category" to mapOf("type" to "STRING", "description" to "Optional category filter")
                )
            )
        )
    }
}

class DeleteMemoryAction(private val repository: MemoryRepository) : DeviceAction {
    override val name: String = "deleteMemory"
    override val description: String = "Deletes a specific memory when the user explicitly asks to forget it."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val query = (args["query"] as? String)?.trim()
            ?: return ActionResult(false, "Query or memory key is required", name)

        val (deleted, item) = repository.deleteByKeyOrQuery(query)
        return if (deleted && item != null) {
            ActionResult(true, "Successfully forgot: \"${item.key}\"", name, mapOf("deleted" to item.key))
        } else {
            ActionResult(false, "Could not find any memory matching \"$query\" to delete.", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "query" to mapOf("type" to "STRING", "description" to "The key, title or topic to forget")
                ),
                "required" to listOf("query")
            )
        )
    }
}

class DeleteAllMemoriesAction(private val repository: MemoryRepository) : DeviceAction {
    override val name: String = "deleteAllMemories"
    override val description: String = "Deletes ALL stored memories ONLY when explicitly confirmed by the user."
    override val requiresConfirmation: Boolean = true

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val confirmed = args["confirmed"] as? Boolean ?: false
        if (!confirmed) {
            return ActionResult(
                success = false,
                message = "Deletion cancelled: explicit user confirmation is required to delete all memories.",
                actionName = name,
                requiresUserConfirmation = true,
                confirmationPrompt = "Are you sure you want to delete all saved memories?"
            )
        }

        val count = repository.deleteAll()
        return ActionResult(true, "Cleared all $count memories.", name, mapOf("count" to count))
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "confirmed" to mapOf("type" to "BOOLEAN", "description" to "True ONLY if user explicitly confirmed deletion of all memories")
                ),
                "required" to listOf("confirmed")
            )
        )
    }
}
