package com.salony.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.salony.ai.actions.DeviceActionRegistry
import com.salony.ai.data.ActionLogRepository
import com.salony.ai.data.MemoryRepository
import com.salony.ai.data.PreferencesManager

class SalonyApplication : Application() {

    lateinit var preferencesManager: PreferencesManager
        private set

    lateinit var memoryRepository: MemoryRepository
        private set

    lateinit var actionLogRepository: ActionLogRepository
        private set

    lateinit var actionRegistry: DeviceActionRegistry
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        preferencesManager = PreferencesManager(this)
        memoryRepository = MemoryRepository(this)
        actionLogRepository = ActionLogRepository(this)
        actionRegistry = DeviceActionRegistry(this, memoryRepository, actionLogRepository)

        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_VOICE_SERVICE,
                getString(R.string.voice_service_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.voice_service_channel_desc)
                setShowBadge(false)
            }

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_VOICE_SERVICE = "salony_voice_service_channel"
        lateinit var instance: SalonyApplication
            private set
    }
}
