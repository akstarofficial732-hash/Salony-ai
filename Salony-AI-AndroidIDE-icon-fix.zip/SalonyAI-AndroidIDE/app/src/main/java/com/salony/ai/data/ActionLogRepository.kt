package com.salony.ai.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.salony.ai.model.ActionLogItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class ActionLogRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("salony_action_logs", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _logs = MutableStateFlow<List<ActionLogItem>>(emptyList())
    val logs: StateFlow<List<ActionLogItem>> = _logs.asStateFlow()

    init {
        loadLogs()
    }

    @Synchronized
    private fun loadLogs() {
        val json = prefs.getString(KEY_LOGS, null)
        if (!json.isNullOrEmpty()) {
            val type = object : TypeToken<List<ActionLogItem>>() {}.type
            try {
                val list = gson.fromJson<List<ActionLogItem>>(json, type) ?: emptyList()
                _logs.value = list
            } catch (e: Exception) {
                _logs.value = emptyList()
            }
        }
    }

    @Synchronized
    fun addLog(actionName: String, description: String, success: Boolean, details: String? = null) {
        val current = _logs.value.toMutableList()
        val item = ActionLogItem(
            id = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            actionName = actionName,
            description = description,
            success = success,
            details = details
        )
        current.add(0, item)
        // Keep last 100 entries
        if (current.size > 100) {
            current.removeAt(current.size - 1)
        }
        _logs.value = current
        val json = gson.toJson(current)
        prefs.edit().putString(KEY_LOGS, json).apply()
    }

    @Synchronized
    fun clearLogs() {
        _logs.value = emptyList()
        prefs.edit().remove(KEY_LOGS).apply()
    }

    companion object {
        private const val KEY_LOGS = "key_logs_list"
    }
}
