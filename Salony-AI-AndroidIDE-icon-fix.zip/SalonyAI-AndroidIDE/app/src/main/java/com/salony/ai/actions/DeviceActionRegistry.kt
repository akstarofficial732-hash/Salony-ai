package com.salony.ai.actions

import android.content.Context
import com.salony.ai.data.ActionLogRepository
import com.salony.ai.data.MemoryRepository
import com.salony.ai.model.ActionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DeviceActionRegistry(
    private val context: Context,
    private val memoryRepository: MemoryRepository,
    private val actionLogRepository: ActionLogRepository
) {
    private val actions = mutableMapOf<String, DeviceAction>()

    init {
        registerDefaultActions()
    }

    private fun registerDefaultActions() {
        register(OpenAppAction())
        register(OpenWebsiteAction())
        register(OpenSettingsAction())
        register(SetAlarmAction())
        register(SetTimerAction())
        register(DialPhoneAction())
        register(SendSmsAction())
        register(ToggleTorchAction())
        register(SaveMemoryAction(memoryRepository))
        register(SearchMemoriesAction(memoryRepository))
        register(ListMemoriesAction(memoryRepository))
        register(DeleteMemoryAction(memoryRepository))
        register(DeleteAllMemoriesAction(memoryRepository))
    }

    fun register(action: DeviceAction) {
        actions[action.name] = action
    }

    fun getAction(name: String): DeviceAction? = actions[name]

    fun getAllActions(): List<DeviceAction> = actions.values.toList()

    fun getToolDeclarations(): List<Map<String, Any>> {
        return actions.values.map { it.getToolDeclaration() }
    }

    suspend fun execute(actionName: String, args: Map<String, Any?>): ActionResult {
        return withContext(Dispatchers.Main) {
            val action = actions[actionName]
            if (action == null) {
                val errorResult = ActionResult(false, "Unknown device action: $actionName", actionName)
                actionLogRepository.addLog(actionName, "Action not found", false)
                return@withContext errorResult
            }

            try {
                val result = action.execute(context, args)
                actionLogRepository.addLog(
                    actionName = actionName,
                    description = result.message,
                    success = result.success,
                    details = args.toString()
                )
                result
            } catch (e: Exception) {
                val errorResult = ActionResult(false, "Execution failed: ${e.message}", actionName)
                actionLogRepository.addLog(actionName, "Error: ${e.message}", false)
                errorResult
            }
        }
    }
}
