package com.salony.ai.voice

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.salony.ai.actions.DeviceActionRegistry
import com.salony.ai.model.ActionResult
import com.salony.ai.model.VoiceState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.*
import java.util.concurrent.TimeUnit

class GeminiLiveClient(
    private val actionRegistry: DeviceActionRegistry,
    private val scope: CoroutineScope
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private val gson = Gson()

    private val _voiceState = MutableStateFlow(VoiceState.DISCONNECTED)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _lastTranscript = MutableStateFlow<Pair<String, String>?>(null)
    val lastTranscript: StateFlow<Pair<String, String>?> = _lastTranscript.asStateFlow()

    val audioStreamer = AudioRecordStreamer()
    val audioPlayer = AudioTrackPlayer()

    var onActionExecuted: ((ActionResult) -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    init {
        // Streamer -> WebSocket
        audioStreamer.onAudioChunk = { base64 ->
            val payload = JsonObject().apply {
                addProperty("type", "audio")
                addProperty("audio", base64)
            }
            webSocket?.send(payload.toString())
        }

        // Interruption detection from microphone
        audioStreamer.onVolumeLevel = { vol ->
            if (vol > 0.40f && _voiceState.value == VoiceState.SPEAKING) {
                audioPlayer.stop()
                _voiceState.value = VoiceState.LISTENING
            }
        }

        // Player state -> VoiceState
        audioPlayer.onPlaybackStateChange = { isPlaying ->
            if (_voiceState.value != VoiceState.DISCONNECTED && _voiceState.value != VoiceState.CONNECTING) {
                _voiceState.value = if (isPlaying) VoiceState.SPEAKING else VoiceState.LISTENING
            }
        }
    }

    fun connect(wsUrl: String, voiceName: String = "Kore") {
        if (_voiceState.value == VoiceState.CONNECTING || _voiceState.value == VoiceState.LISTENING) {
            return
        }

        _voiceState.value = VoiceState.CONNECTING

        val request = Request.Builder()
            .url("$wsUrl?voice=$voiceName")
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                scope.launch(Dispatchers.Main) {
                    val started = audioStreamer.start(scope)
                    if (started) {
                        _voiceState.value = VoiceState.LISTENING
                    } else {
                        onError?.invoke("Microphone permission required for voice interaction.")
                        disconnect()
                    }
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                scope.launch(Dispatchers.Main) {
                    try {
                        val json = JsonParser.parseString(text).asJsonObject
                        val type = json.get("type")?.asString

                        when (type) {
                            "audio" -> {
                                val audioData = json.get("audio")?.asString
                                if (!audioData.isNullOrEmpty()) {
                                    audioPlayer.queueAudioChunk(audioData, scope)
                                }
                            }
                            "interrupted" -> {
                                audioPlayer.stop()
                                _voiceState.value = VoiceState.LISTENING
                            }
                            "turn_complete" -> {
                                if (!audioPlayer.isCurrentlyPlaying) {
                                    _voiceState.value = VoiceState.LISTENING
                                }
                            }
                            "transcript" -> {
                                val role = json.get("role")?.asString ?: "model"
                                val transcriptText = json.get("text")?.asString ?: ""
                                _lastTranscript.value = Pair(role, transcriptText)
                            }
                            "tool_call" -> {
                                val callId = json.get("callId")?.asString ?: ""
                                val actionName = json.get("name")?.asString ?: ""
                                val argsJson = json.get("args")?.asJsonObject
                                val argsMap = mutableMapOf<String, Any?>()
                                argsJson?.entrySet()?.forEach { (k, v) ->
                                    argsMap[k] = when {
                                        v.isJsonPrimitive && v.asJsonPrimitive.isBoolean -> v.asBoolean
                                        v.isJsonPrimitive && v.asJsonPrimitive.isNumber -> v.asNumber
                                        else -> v.asString
                                    }
                                }

                                // Execute local Android action
                                val result = actionRegistry.execute(actionName, argsMap)
                                onActionExecuted?.invoke(result)

                                // Return response to WebSocket
                                val responsePayload = JsonObject().apply {
                                    addProperty("type", "tool_response")
                                    addProperty("callId", callId)
                                    addProperty("name", actionName)
                                    val resultObj = JsonObject().apply {
                                        addProperty("success", result.success)
                                        addProperty("message", result.message)
                                    }
                                    add("result", resultObj)
                                }
                                webSocket.send(responsePayload.toString())
                            }
                            "error" -> {
                                val errorMsg = json.get("error")?.asString ?: "Voice session error"
                                onError?.invoke(errorMsg)
                            }
                        }
                    } catch (e: Exception) {
                        // ignore parse error
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                scope.launch(Dispatchers.Main) {
                    onError?.invoke(t.message ?: "Connection failure")
                    disconnect()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                scope.launch(Dispatchers.Main) {
                    disconnect()
                }
            }
        })
    }

    fun sendTextPrompt(prompt: String) {
        val payload = JsonObject().apply {
            addProperty("type", "text")
            addProperty("text", prompt)
        }
        webSocket?.send(payload.toString())
        _lastTranscript.value = Pair("user", prompt)
    }

    fun interrupt() {
        audioPlayer.stop()
        if (_voiceState.value != VoiceState.DISCONNECTED) {
            _voiceState.value = VoiceState.LISTENING
        }
    }

    fun disconnect() {
        audioStreamer.stop()
        audioPlayer.stop()
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        _voiceState.value = VoiceState.DISCONNECTED
    }

    fun release() {
        disconnect()
        audioPlayer.release()
    }
}
