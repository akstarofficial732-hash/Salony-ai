package com.salony.ai.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.salony.ai.model.ActionResult

class DialPhoneAction : DeviceAction {
    override val name: String = "dialPhone"
    override val description: String = "Prepares or dials a phone number in the system dialer for user review before calling."
    override val requiresConfirmation: Boolean = true

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val phoneNumber = (args["phone_number"] as? String)?.trim()
            ?: return ActionResult(false, "Phone number is required", name)

        val cleanNumber = phoneNumber.replace(Regex("[^0-9+]"), "")
        if (cleanNumber.isEmpty()) {
            return ActionResult(false, "Invalid phone number format", name)
        }

        // Safe dialer: uses ACTION_DIAL so the user sees the screen and presses call button
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanNumber")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ActionResult(
                success = true,
                message = "Opened dialer with phone number $cleanNumber. Please press call to confirm.",
                actionName = name,
                details = mapOf("number" to cleanNumber),
                requiresUserConfirmation = true,
                confirmationPrompt = "Call $cleanNumber?"
            )
        } catch (e: Exception) {
            ActionResult(false, "Could not open dialer: ${e.message}", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "phone_number" to mapOf("type" to "STRING", "description" to "The phone number to dial"),
                    "contact_name" to mapOf("type" to "STRING", "description" to "Optional contact name")
                ),
                "required" to listOf("phone_number")
            )
        )
    }
}

class SendSmsAction : DeviceAction {
    override val name: String = "sendSms"
    override val description: String = "Prepares an SMS message in the default messaging app for user review and confirmation before sending."
    override val requiresConfirmation: Boolean = true

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val phoneNumber = (args["phone_number"] as? String)?.trim() ?: ""
        val message = (args["message"] as? String)?.trim()
            ?: return ActionResult(false, "Message text is required", name)

        val uri = if (phoneNumber.isNotEmpty()) {
            Uri.parse("smsto:${phoneNumber.replace(Regex("[^0-9+]"), "")}")
        } else {
            Uri.parse("smsto:")
        }

        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ActionResult(
                success = true,
                message = "Prepared message for user review and send confirmation.",
                actionName = name,
                details = mapOf("recipient" to phoneNumber, "message" to message),
                requiresUserConfirmation = true,
                confirmationPrompt = "Send SMS to $phoneNumber?"
            )
        } catch (e: Exception) {
            ActionResult(false, "Could not prepare SMS: ${e.message}", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "phone_number" to mapOf("type" to "STRING", "description" to "Recipient phone number"),
                    "message" to mapOf("type" to "STRING", "description" to "Text message content")
                ),
                "required" to listOf("message")
            )
        )
    }
}
