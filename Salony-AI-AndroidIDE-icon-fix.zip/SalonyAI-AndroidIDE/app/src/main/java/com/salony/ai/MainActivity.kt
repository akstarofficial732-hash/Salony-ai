package com.salony.ai

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.salony.ai.model.ActionResult
import com.salony.ai.model.VoiceState
import com.salony.ai.ui.screens.*
import com.salony.ai.ui.theme.DeepBlack
import com.salony.ai.ui.theme.SalonyAITheme
import com.salony.ai.voice.VoiceAssistantService

enum class AppScreen {
    HOME,
    MEMORIES,
    ACTION_LOG,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private var voiceService: VoiceAssistantService? = null
    private var isBound by mutableStateOf(false)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as VoiceAssistantService.LocalBinder
            voiceService = binder.getService()
            isBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            voiceService = null
            isBound = false
        }
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (!recordAudioGranted) {
            Toast.makeText(this, "Microphone permission is needed for voice conversations.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        checkAndRequestPermissions()

        val serviceIntent = Intent(this, VoiceAssistantService::class.java).apply {
            action = VoiceAssistantService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)

        val app = application as SalonyApplication

        setContent {
            SalonyAITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DeepBlack
                ) {
                    var currentScreen by remember { mutableStateOf(AppScreen.HOME) }
                    var pendingConfirmation by remember { mutableStateOf<ActionResult?>(null) }
                    var isTorchOn by remember { mutableStateOf(false) }

                    var inputVolume by remember { mutableFloatStateOf(0f) }
                    var outputVolume by remember { mutableFloatStateOf(0f) }

                    val memories by app.memoryRepository.memories.collectAsState()

                    // Voice State & Transcripts from Service
                    val voiceState = voiceService?.client?.voiceState?.collectAsState()?.value
                        ?: VoiceState.DISCONNECTED
                    val lastTranscript = voiceService?.client?.lastTranscript?.collectAsState()?.value

                    LaunchedEffect(voiceService) {
                        voiceService?.client?.audioStreamer?.onVolumeLevel = { vol ->
                            inputVolume = vol
                        }
                        voiceService?.client?.audioPlayer?.onVolumeLevel = { vol ->
                            outputVolume = vol
                        }
                        voiceService?.client?.onActionExecuted = { result ->
                            if (result.requiresUserConfirmation) {
                                pendingConfirmation = result
                            }
                            if (result.actionName == "toggleTorch") {
                                isTorchOn = result.details["enabled"] as? Boolean ?: false
                            }
                            Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_SHORT).show()
                        }
                        voiceService?.client?.onError = { errMsg ->
                            Toast.makeText(this@MainActivity, errMsg, Toast.LENGTH_LONG).show()
                        }
                    }

                    when (currentScreen) {
                        AppScreen.HOME -> {
                            HomeScreen(
                                voiceState = voiceState,
                                inputVolume = inputVolume,
                                outputVolume = outputVolume,
                                lastTranscript = lastTranscript,
                                memoryCount = memories.size,
                                isTorchOn = isTorchOn,
                                pendingConfirmation = pendingConfirmation,
                                onToggleConnect = {
                                    if (voiceState == VoiceState.DISCONNECTED) {
                                        val wsUrl = app.preferencesManager.serverUrl
                                        val voice = app.preferencesManager.selectedVoice
                                        voiceService?.client?.connect(wsUrl, voice)
                                    } else {
                                        voiceService?.client?.disconnect()
                                    }
                                },
                                onToggleMute = {
                                    if (voiceService?.client?.audioStreamer?.isActiveStreaming == true) {
                                        voiceService?.client?.audioStreamer?.stop()
                                    }
                                },
                                onInterrupt = {
                                    voiceService?.client?.interrupt()
                                },
                                onSendPrompt = { prompt ->
                                    if (voiceState == VoiceState.DISCONNECTED) {
                                        val wsUrl = app.preferencesManager.serverUrl
                                        val voice = app.preferencesManager.selectedVoice
                                        voiceService?.client?.connect(wsUrl, voice)
                                        // Wait briefly for connection
                                        window.decorView.postDelayed({
                                            voiceService?.client?.sendTextPrompt(prompt)
                                        }, 800)
                                    } else {
                                        voiceService?.client?.sendTextPrompt(prompt)
                                    }
                                },
                                onToggleTorch = {
                                    isTorchOn = !isTorchOn
                                    // Toggle through action
                                    voiceService?.let {
                                        kotlinx.coroutines.MainScope().run {
                                            app.actionRegistry.execute("toggleTorch", mapOf("enable" to isTorchOn))
                                        }
                                    }
                                },
                                onOpenMemories = { currentScreen = AppScreen.MEMORIES },
                                onOpenLogs = { currentScreen = AppScreen.ACTION_LOG },
                                onOpenSettings = { currentScreen = AppScreen.SETTINGS },
                                onConfirmAction = { action ->
                                    pendingConfirmation = null
                                    Toast.makeText(this@MainActivity, "Action confirmed: ${action.actionName}", Toast.LENGTH_SHORT).show()
                                },
                                onDismissConfirmation = {
                                    pendingConfirmation = null
                                }
                            )
                        }

                        AppScreen.MEMORIES -> {
                            MemoryDashboardScreen(
                                repository = app.memoryRepository,
                                onBack = { currentScreen = AppScreen.HOME }
                            )
                        }

                        AppScreen.ACTION_LOG -> {
                            ActionLogScreen(
                                repository = app.actionLogRepository,
                                onBack = { currentScreen = AppScreen.HOME }
                            )
                        }

                        AppScreen.SETTINGS -> {
                            SettingsScreen(
                                prefs = app.preferencesManager,
                                onBack = { currentScreen = AppScreen.HOME }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isBound) {
            unbindService(serviceConnection)
            isBound = false
        }
    }
}
