package com.salony.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.salony.ai.model.VoiceState
import com.salony.ai.ui.theme.*

@Composable
fun AnimatedAIOrb(
    voiceState: VoiceState,
    inputVolume: Float,
    outputVolume: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_anim")

    // Ambient breathing
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Gyro rotation for connecting & active
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                when (voiceState) {
                    VoiceState.CONNECTING -> 4000
                    VoiceState.SPEAKING -> 8000
                    VoiceState.LISTENING -> 14000
                    VoiceState.DISCONNECTED -> 24000
                },
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val reactiveVol = when (voiceState) {
        VoiceState.SPEAKING -> outputVolume
        VoiceState.LISTENING -> inputVolume
        else -> 0f
    }

    val dynamicScale = (pulseScale + (reactiveVol * 0.35f)).coerceIn(0.8f, 1.5f)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(320.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(260.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 2.6f) * dynamicScale

            // Outer Bloom Aura
            val auraColor = when (voiceState) {
                VoiceState.SPEAKING -> NeonPurple.copy(alpha = 0.25f + reactiveVol * 0.3f)
                VoiceState.LISTENING -> NeonCyan.copy(alpha = 0.25f + reactiveVol * 0.3f)
                VoiceState.CONNECTING -> NeonPurple.copy(alpha = 0.20f)
                VoiceState.DISCONNECTED -> Color(0x1A4C1D95)
            }
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(auraColor, Color.Transparent),
                    center = center,
                    radius = baseRadius * 1.6f
                ),
                radius = baseRadius * 1.6f,
                center = center
            )

            // Outer Gyroscope Rings
            drawCircle(
                color = if (voiceState == VoiceState.CONNECTING) NeonCyan.copy(alpha = 0.6f) else BorderSubtle,
                radius = baseRadius * 1.25f,
                center = center,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 25f), rotation * 2)
                )
            )

            drawCircle(
                color = if (voiceState == VoiceState.SPEAKING) NeonPink.copy(alpha = 0.5f) else BorderSubtle,
                radius = baseRadius * 1.4f,
                center = center,
                style = Stroke(
                    width = 1.5.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 30f), -rotation * 1.5f)
                )
            )

            // Core Sphere Gradient
            val coreColors = when (voiceState) {
                VoiceState.SPEAKING -> listOf(
                    NeonPink,
                    NeonPurple,
                    DeepBlack
                )
                VoiceState.LISTENING -> listOf(
                    NeonCyan,
                    Color(0xFF3B82F6),
                    DeepBlack
                )
                VoiceState.CONNECTING -> listOf(
                    NeonPurple,
                    NeonCyan,
                    DeepBlack
                )
                VoiceState.DISCONNECTED -> listOf(
                    Color(0xFF4C1D95),
                    Color(0xFF1E1B4B),
                    DeepBlack
                )
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = coreColors,
                    center = center.copy(y = center.y - (baseRadius * 0.2f)),
                    radius = baseRadius
                ),
                radius = baseRadius,
                center = center
            )

            // Specular Glint Highlight on glass top
            drawCircle(
                color = Color.White.copy(alpha = 0.25f),
                radius = baseRadius * 0.35f,
                center = center.copy(x = center.x - baseRadius * 0.25f, y = center.y - baseRadius * 0.35f)
            )
        }
    }
}
