package com.salony.ai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.salony.ai.model.VoiceState
import com.salony.ai.ui.theme.*

@Composable
fun VoiceControls(
    voiceState: VoiceState,
    isMuted: Boolean,
    onToggleConnect: () -> Unit,
    onToggleMute: () -> Unit,
    onInterrupt: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = voiceState != VoiceState.DISCONNECTED

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_ring")
    val ringScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ring_scale"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left Button: Mute
        if (isConnected) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isMuted) NeonPink.copy(alpha = 0.2f) else SurfaceCard)
                    .border(1.dp, if (isMuted) NeonPink else BorderSubtle, CircleShape)
                    .clickable { onToggleMute() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "Mute",
                    tint = if (isMuted) NeonPink else TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        } else {
            Spacer(modifier = Modifier.size(48.dp))
        }

        // Main Center Button
        Box(contentAlignment = Alignment.Center) {
            if (isConnected) {
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .scale(ringScale)
                        .clip(CircleShape)
                        .border(2.dp, NeonCyan.copy(alpha = 0.4f), CircleShape)
                )
            }

            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(
                        if (isConnected) {
                            Brush.linearGradient(listOf(NeonPink, NeonPurple, NeonCyan))
                        } else {
                            Brush.linearGradient(listOf(NeonPurple, NeonCyan))
                        }
                    )
                    .border(2.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                    .clickable { onToggleConnect() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isConnected) Icons.Default.CallEnd else Icons.Default.Mic,
                    contentDescription = if (isConnected) "Disconnect" else "Start Voice",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }
        }

        // Right Button: Interrupt / Stop Speaking
        if (isConnected) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(SurfaceCard)
                    .border(1.dp, BorderSubtle, CircleShape)
                    .clickable {
                        if (voiceState == VoiceState.SPEAKING) onInterrupt() else onToggleConnect()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (voiceState == VoiceState.SPEAKING) Icons.Default.Stop else Icons.Default.CallEnd,
                    contentDescription = "Interrupt",
                    tint = if (voiceState == VoiceState.SPEAKING) NeonAmber else Color(0xFFEF4444),
                    modifier = Modifier.size(22.dp)
                )
            }
        } else {
            Spacer(modifier = Modifier.size(48.dp))
        }
    }
}
