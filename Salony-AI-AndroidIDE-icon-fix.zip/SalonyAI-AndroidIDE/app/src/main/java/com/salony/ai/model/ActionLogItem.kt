package com.salony.ai.model

data class ActionLogItem(
    val id: String,
    val timestamp: Long,
    val actionName: String,
    val description: String,
    val success: Boolean,
    val details: String? = null
)
