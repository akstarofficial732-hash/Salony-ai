package com.salony.ai.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.salony.ai.model.MemoryItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class MemoryRepository(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("salony_memories_db", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _memories = MutableStateFlow<List<MemoryItem>>(emptyList())
    val memories: StateFlow<List<MemoryItem>> = _memories.asStateFlow()

    init {
        loadMemories()
    }

    @Synchronized
    private fun loadMemories() {
        val json = prefs.getString(KEY_MEMORIES_LIST, null)
        val list = if (!json.isNullOrEmpty()) {
            val type = object : TypeToken<List<MemoryItem>>() {}.type
            try {
                gson.fromJson<List<MemoryItem>>(json, type) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        } else {
            // Default seed
            listOf(
                MemoryItem(
                    id = "welcome-android-1",
                    category = "personal",
                    key = "Assistant Relationship",
                    content = "Salony is your sweet, caring, and loving Android personal assistant.",
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis(),
                    tags = listOf("android", "companion")
                )
            )
        }
        _memories.value = list.sortedByDescending { it.updatedAt }
        saveToDisk(_memories.value)
    }

    @Synchronized
    private fun saveToDisk(list: List<MemoryItem>) {
        val json = gson.toJson(list)
        prefs.edit().putString(KEY_MEMORIES_LIST, json).apply()
    }

    @Synchronized
    fun getAll(): List<MemoryItem> {
        return _memories.value
    }

    @Synchronized
    fun search(query: String? = null, category: String? = null): List<MemoryItem> {
        var result = _memories.value

        if (!category.isNullOrEmpty() && category.lowercase() != "all") {
            result = result.filter { it.category.equals(category, ignoreCase = true) }
        }

        if (!query.isNullOrBlank()) {
            val q = query.trim().lowercase()
            result = result.filter {
                it.key.lowercase().contains(q) ||
                it.content.lowercase().contains(q) ||
                it.tags.any { tag -> tag.lowercase().contains(q) }
            }
        }

        return result
    }

    @Synchronized
    fun save(key: String, content: String, category: String = "general", tags: List<String> = emptyList()): MemoryItem {
        val current = _memories.value.toMutableList()
        val now = System.currentTimeMillis()

        // Check if existing item with matching key exists
        val existingIndex = current.indexOfFirst { it.key.equals(key.trim(), ignoreCase = true) }
        val item: MemoryItem

        if (existingIndex >= 0) {
            val old = current[existingIndex]
            item = old.copy(
                content = content.trim(),
                category = category,
                updatedAt = now,
                tags = if (tags.isNotEmpty()) tags else old.tags
            )
            current[existingIndex] = item
        } else {
            item = MemoryItem(
                id = UUID.randomUUID().toString(),
                category = category,
                key = key.trim(),
                content = content.trim(),
                createdAt = now,
                updatedAt = now,
                tags = tags
            )
            current.add(0, item)
        }

        _memories.value = current.sortedByDescending { it.updatedAt }
        saveToDisk(_memories.value)
        return item
    }

    @Synchronized
    fun update(id: String, key: String?, content: String?, category: String?): MemoryItem? {
        val current = _memories.value.toMutableList()
        val index = current.indexOfFirst { it.id == id }
        if (index == -1) return null

        val old = current[index]
        val updated = old.copy(
            key = key?.trim() ?: old.key,
            content = content?.trim() ?: old.content,
            category = category ?: old.category,
            updatedAt = System.currentTimeMillis()
        )
        current[index] = updated
        _memories.value = current.sortedByDescending { it.updatedAt }
        saveToDisk(_memories.value)
        return updated
    }

    @Synchronized
    fun delete(id: String): Boolean {
        val current = _memories.value.toMutableList()
        val removed = current.removeAll { it.id == id }
        if (removed) {
            _memories.value = current
            saveToDisk(current)
        }
        return removed
    }

    @Synchronized
    fun deleteByKeyOrQuery(query: String): Pair<Boolean, MemoryItem?> {
        val current = _memories.value.toMutableList()
        val q = query.trim().lowercase()
        val target = current.find {
            it.key.lowercase() == q || it.key.lowercase().contains(q) || q.contains(it.key.lowercase())
        }

        return if (target != null) {
            current.remove(target)
            _memories.value = current
            saveToDisk(current)
            Pair(true, target)
        } else {
            Pair(false, null)
        }
    }

    @Synchronized
    fun deleteAll(): Int {
        val count = _memories.value.size
        _memories.value = emptyList()
        saveToDisk(emptyList())
        return count
    }

    fun formatForPrompt(): String {
        val list = _memories.value
        if (list.isEmpty()) {
            return "No persistent memories saved yet."
        }
        return list.joinToString("\n") {
            "- [${it.category.uppercase()}] ${it.key}: \"${it.content}\""
        }
    }

    companion object {
        private const val KEY_MEMORIES_LIST = "key_memories_list"
    }
}
