package com.salony.ai.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salony.ai.ui.theme.*

@Composable
fun SubtitleBar(
    lastTranscript: Pair<String, String>?,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .heightIn(min = 52.dp),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = lastTranscript != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            val isModel = lastTranscript?.first == "model"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (isModel) NeonPurple.copy(alpha = 0.12f) else NeonCyan.copy(alpha = 0.12f),
                        RoundedCornerShape(16.dp)
                    )
                    .border(
                        1.dp,
                        if (isModel) NeonPurple.copy(alpha = 0.35f) else NeonCyan.copy(alpha = 0.35f),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = "\"${lastTranscript?.second ?: ""}\"",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontStyle = FontStyle.Italic,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        if (lastTranscript == null) {
            Text(
                text = "✨ Natural Hindi, Hinglish & English Phone Assistant",
                color = TextMuted.copy(alpha = 0.6f),
                fontSize = 11.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
