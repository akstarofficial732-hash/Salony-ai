package com.salony.ai.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.sqrt

class AudioTrackPlayer {
    private var audioTrack: AudioTrack? = null
    private var playbackJob: Job? = null
    private val audioQueue = ConcurrentLinkedQueue<ByteArray>()
    private var isPlaying = false

    var onPlaybackStateChange: ((Boolean) -> Unit)? = null
    var onVolumeLevel: ((Float) -> Unit)? = null

    companion object {
        const val SAMPLE_RATE = 24000
        const val CHANNEL_CONFIG = AudioFormat.CHANNEL_OUT_MONO
        const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    private fun initAudioTrack() {
        if (audioTrack == null) {
            val minBufSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AUDIO_FORMAT)
                        .setSampleRate(SAMPLE_RATE)
                        .setChannelMask(CHANNEL_CONFIG)
                        .build()
                )
                .setBufferSizeInBytes(minBufSize * 2)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
        }
    }

    fun queueAudioChunk(base64Data: String, scope: CoroutineScope) {
        val pcm = Base64.decode(base64Data, Base64.NO_WRAP)
        audioQueue.add(pcm)

        if (!isPlaying) {
            isPlaying = true
            onPlaybackStateChange?.invoke(true)
            startPlaybackLoop(scope)
        }
    }

    private fun startPlaybackLoop(scope: CoroutineScope) {
        playbackJob?.cancel()
        playbackJob = scope.launch(Dispatchers.IO) {
            initAudioTrack()

            while (isActive && isPlaying) {
                val chunk = audioQueue.poll()
                if (chunk != null) {
                    // Compute amplitude
                    var sum = 0.0
                    for (i in 0 until chunk.size step 2) {
                        val sample = (chunk[i].toInt() and 0xFF) or (chunk[i + 1].toInt() shl 8)
                        val sampleFloat = sample.toShort() / 32768.0
                        sum += sampleFloat * sampleFloat
                    }
                    val rms = sqrt(sum / (chunk.size / 2)).toFloat()
                    withContext(Dispatchers.Main) {
                        onVolumeLevel?.invoke((rms * 3.5f).coerceIn(0f, 1f))
                    }

                    audioTrack?.write(chunk, 0, chunk.size)
                } else {
                    // Queue empty
                    delay(50)
                    if (audioQueue.isEmpty()) {
                        isPlaying = false
                        withContext(Dispatchers.Main) {
                            onPlaybackStateChange?.invoke(false)
                            onVolumeLevel?.invoke(0f)
                        }
                        break
                    }
                }
            }
        }
    }

    fun stop() {
        isPlaying = false
        audioQueue.clear()
        playbackJob?.cancel()
        playbackJob = null
        try {
            audioTrack?.pause()
            audioTrack?.flush()
        } catch (e: Exception) {
            // ignore
        }
        onPlaybackStateChange?.invoke(false)
        onVolumeLevel?.invoke(0f)
    }

    fun release() {
        stop()
        try {
            audioTrack?.release()
        } catch (e: Exception) {
            // ignore
        }
        audioTrack = null
    }

    val isCurrentlyPlaying: Boolean
        get() = isPlaying
}
