package com.salony.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NeonPurple,
    secondary = NeonCyan,
    tertiary = NeonPink,
    background = DeepBlack,
    surface = SurfaceCard,
    onPrimary = DeepBlack,
    onSecondary = DeepBlack,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun SalonyAITheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
