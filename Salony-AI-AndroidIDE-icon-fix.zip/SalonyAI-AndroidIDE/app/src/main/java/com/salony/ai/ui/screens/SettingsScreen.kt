package com.salony.ai.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salony.ai.accessibility.SalonyAccessibilityService
import com.salony.ai.data.PreferencesManager
import com.salony.ai.ui.theme.*

@Composable
fun SettingsScreen(
    prefs: PreferencesManager,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var serverUrl by remember { mutableStateOf(prefs.serverUrl) }
    var selectedVoice by remember { mutableStateOf(prefs.selectedVoice) }
    var isSoundFxEnabled by remember { mutableStateOf(prefs.isSoundFxEnabled) }
    var isAccessibilityOptIn by remember { mutableStateOf(prefs.isAccessibilityRequested) }

    val voices = listOf(
        Pair("Kore", "Warm, sweet & caring girlfriend persona (Recommended)"),
        Pair("Aoede", "Gentle, expressive & soft female voice"),
        Pair("Zephyr", "Bright, playful & clear female voice"),
        Pair("Puck", "Energetic & cheerful voice"),
        Pair("Charon", "Calm & deep voice")
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text(
                    text = "Assistant Settings",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Preferences, permissions & accessibility",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        // Voice Persona Selection
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SALONY'S VOICE PERSONA",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                voices.forEach { (name, desc) ->
                    val isSelected = selectedVoice == name
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NeonPurple.copy(alpha = 0.2f) else Color.Transparent)
                            .border(1.dp, if (isSelected) NeonPurple else Color.Transparent, RoundedCornerShape(12.dp))
                            .clickable {
                                selectedVoice = name
                                prefs.selectedVoice = name
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = {
                                selectedVoice = name
                                prefs.selectedVoice = name
                            },
                            colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(text = name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = desc, color = TextMuted, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Live API Server Endpoint URL
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "VOICE BACKEND WEBSOCKET URL",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = serverUrl,
                    onValueChange = {
                        serverUrl = it
                        prefs.serverUrl = it
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = BorderSubtle
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Default for Android Emulator: ws://10.0.2.2:3000/live\nFor real phone on Wi-Fi: ws://<Your-PC-IP>:3000/live or Cloud URL",
                    color = TextMuted,
                    fontSize = 10.sp
                )
            }
        }

        // Sound Effects
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Chimes & Sound FX", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "Play chimes on connect, disconnect & actions", color = TextMuted, fontSize = 11.sp)
                }
                Switch(
                    checked = isSoundFxEnabled,
                    onCheckedChange = {
                        isSoundFxEnabled = it
                        prefs.isSoundFxEnabled = it
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan, checkedTrackColor = NeonPurple.copy(alpha = 0.5f))
                )
            }
        }

        // Accessibility Service (Optional)
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Optional Accessibility Assistance",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (SalonyAccessibilityService.isServiceRunning) "Status: Enabled in Android Settings" else "Status: Disabled (Default)",
                            color = if (SalonyAccessibilityService.isServiceRunning) Color(0xFF10B981) else TextMuted,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = isAccessibilityOptIn,
                        onCheckedChange = {
                            isAccessibilityOptIn = it
                            prefs.isAccessibilityRequested = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = NeonCyan)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Privacy & Safety Notice: Salony never enables Accessibility automatically. It is strictly user-directed for screen interactions and system navigation. Salony will NEVER read banking, passwords, or personal credentials.",
                    color = TextMuted,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )

                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Android Accessibility Settings", color = NeonCyan, fontSize = 12.sp)
                }
            }
        }

        // Permissions Management
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderSubtle, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ANDROID PERMISSIONS",
                    color = NeonCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Salony requires Microphone permission for voice interaction, Notification permission for foreground background persistence, and Camera for the flashlight.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Manage App Permissions in Android Settings", color = Color.White, fontSize = 12.sp)
                }
            }
        }
    }
}
