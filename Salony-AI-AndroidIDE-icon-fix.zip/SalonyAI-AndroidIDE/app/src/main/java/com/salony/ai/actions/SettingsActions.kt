package com.salony.ai.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.salony.ai.model.ActionResult

class OpenSettingsAction : DeviceAction {
    override val name: String = "openSettings"
    override val description: String = "Opens Android system settings screen for Wi-Fi, Bluetooth, Display, Sound, Accessibility, or App Info."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val target = (args["target"] as? String)?.trim()?.lowercase() ?: "general"

        val intent = when (target) {
            "wifi", "wi-fi", "internet" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "sound", "volume", "audio" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "display", "brightness" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "app", "app_details", "permissions" -> {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.fromParts("package", context.packageName, null)
                }
            }
            else -> Intent(Settings.ACTION_SETTINGS)
        }.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ActionResult(true, "Opened $target settings screen.", name, mapOf("target" to target))
        } catch (e: Exception) {
            ActionResult(false, "Failed to open settings: ${e.message}", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "target" to mapOf(
                        "type" to "STRING",
                        "description" to "Settings section: wifi, bluetooth, display, sound, accessibility, app_details, general",
                        "enum" to listOf("wifi", "bluetooth", "display", "sound", "accessibility", "app_details", "general")
                    )
                ),
                "required" to listOf("target")
            )
        )
    }
}
