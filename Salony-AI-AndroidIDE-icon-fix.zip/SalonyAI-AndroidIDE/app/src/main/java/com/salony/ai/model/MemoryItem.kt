package com.salony.ai.model

data class MemoryItem(
    val id: String,
    val category: String, // personal, preferences, projects, goals, general
    val key: String,
    val content: String,
    val createdAt: Long,
    val updatedAt: Long,
    val tags: List<String> = emptyList()
)
