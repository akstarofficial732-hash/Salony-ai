package com.salony.ai.data

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("salony_preferences", Context.MODE_PRIVATE)

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, "ws://10.0.2.2:3000/live") ?: "ws://10.0.2.2:3000/live"
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value).apply()

    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    var selectedVoice: String
        get() = prefs.getString(KEY_SELECTED_VOICE, "Kore") ?: "Kore"
        set(value) = prefs.edit().putString(KEY_SELECTED_VOICE, value).apply()

    var isSoundFxEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND_FX, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND_FX, value).apply()

    var isAccessibilityRequested: Boolean
        get() = prefs.getBoolean(KEY_ACCESSIBILITY_OPT_IN, false)
        set(value) = prefs.edit().putBoolean(KEY_ACCESSIBILITY_OPT_IN, value).apply()

    companion object {
        private const val KEY_SERVER_URL = "key_server_url"
        private const val KEY_API_KEY = "key_api_key"
        private const val KEY_SELECTED_VOICE = "key_selected_voice"
        private const val KEY_SOUND_FX = "key_sound_fx"
        private const val KEY_ACCESSIBILITY_OPT_IN = "key_accessibility_opt_in"
    }
}
