package com.salony.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salony.ai.model.ActionResult
import com.salony.ai.model.VoiceState
import com.salony.ai.ui.components.*
import com.salony.ai.ui.theme.*

@Composable
fun HomeScreen(
    voiceState: VoiceState,
    inputVolume: Float,
    outputVolume: Float,
    lastTranscript: Pair<String, String>?,
    memoryCount: Int,
    isTorchOn: Boolean,
    pendingConfirmation: ActionResult?,
    onToggleConnect: () -> Unit,
    onToggleMute: () -> Unit,
    onInterrupt: () -> Unit,
    onSendPrompt: (String) -> Unit,
    onToggleTorch: () -> Unit,
    onOpenMemories: () -> Unit,
    onOpenLogs: () -> Unit,
    onOpenSettings: () -> Unit,
    onConfirmAction: (ActionResult) -> Unit,
    onDismissConfirmation: () -> Unit,
    modifier: Modifier = Modifier
) {
    val suggestions = listOf(
        "Salony, YouTube kholo",
        "Salony, torch on karo",
        "Salony, 7 baje ka alarm lagao",
        "Salony, yaad rakhna mera fav colour blue hai",
        "Mere baare me kya yaad hai?",
        "Salony, Wi-Fi settings kholo"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepBlack)
            .statusBarsPadding()
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Title
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NeonPurple.copy(alpha = 0.2f))
                        .border(1.dp, NeonPurple, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Logo",
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "SALONY AI",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(NeonPurple.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "ANDROID",
                                color = NeonPurple,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "Phone Assistant & Companion",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            // Action Icons Row
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Torch Button
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isTorchOn) NeonAmber else SurfaceCard)
                        .border(1.dp, if (isTorchOn) NeonAmber else BorderSubtle, RoundedCornerShape(10.dp))
                        .clickable { onToggleTorch() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FlashlightOn,
                        contentDescription = "Torch",
                        tint = if (isTorchOn) DeepBlack else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Memory Dashboard Button
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceCard)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                        .clickable { onOpenMemories() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = "Memories",
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    if (memoryCount > 0) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = 4.dp, y = (-4).dp)
                                .size(16.dp)
                                .clip(CircleShape)
                                .background(NeonCyan),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = memoryCount.toString(),
                                color = DeepBlack,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Action Log Button
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceCard)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                        .clickable { onOpenLogs() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Logs",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Settings Button
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceCard)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                        .clickable { onOpenSettings() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Center Area: Animated AI Orb & Status Indicator
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AnimatedAIOrb(
                voiceState = voiceState,
                inputVolume = inputVolume,
                outputVolume = outputVolume,
                onClick = {
                    if (voiceState == VoiceState.SPEAKING) onInterrupt() else onToggleConnect()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            StatusIndicator(voiceState = voiceState)
        }

        // Bottom Controls
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            SubtitleBar(lastTranscript = lastTranscript)

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Voice Suggestions Carousel
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(suggestions) { prompt ->
                    Box(
                        modifier = Modifier
                            .background(SurfaceCard, RoundedCornerShape(50.dp))
                            .border(1.dp, BorderSubtle, RoundedCornerShape(50.dp))
                            .clickable { onSendPrompt(prompt) }
                            .padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = prompt,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            VoiceControls(
                voiceState = voiceState,
                isMuted = false,
                onToggleConnect = onToggleConnect,
                onToggleMute = onToggleMute,
                onInterrupt = onInterrupt
            )
        }
    }

    // Safety Confirmation Dialog for consequential actions
    if (pendingConfirmation != null) {
        AlertDialog(
            onDismissRequest = onDismissConfirmation,
            title = {
                Text(text = "Confirm Action", fontWeight = FontWeight.Bold, color = TextPrimary)
            },
            text = {
                Text(
                    text = pendingConfirmation.confirmationPrompt ?: pendingConfirmation.message,
                    color = TextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = { onConfirmAction(pendingConfirmation) },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                ) {
                    Text("Confirm", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = onDismissConfirmation) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = SurfaceCard,
            shape = RoundedCornerShape(20.dp)
        )
    }
}
