package com.salony.ai.model

enum class VoiceState {
    DISCONNECTED,
    CONNECTING,
    LISTENING,
    SPEAKING
}
