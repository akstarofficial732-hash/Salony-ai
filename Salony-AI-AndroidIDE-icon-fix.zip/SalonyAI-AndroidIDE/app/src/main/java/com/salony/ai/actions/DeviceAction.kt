package com.salony.ai.actions

import android.content.Context
import com.salony.ai.model.ActionResult

interface DeviceAction {
    /**
     * Unique function name matching Gemini tool declaration (e.g. openApp, setAlarm)
     */
    val name: String

    /**
     * Friendly description
     */
    val description: String

    /**
     * If true, requires explicit confirmation before executing consequential actions
     */
    val requiresConfirmation: Boolean get() = false

    /**
     * Executes the action on Android device
     */
    suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult

    /**
     * Tool declaration parameter schema in JSON map form
     */
    fun getToolDeclaration(): Map<String, Any>
}
