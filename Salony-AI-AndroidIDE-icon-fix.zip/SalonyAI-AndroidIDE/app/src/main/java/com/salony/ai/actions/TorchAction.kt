package com.salony.ai.actions

import android.content.Context
import android.hardware.camera2.CameraManager
import android.os.Build
import com.salony.ai.model.ActionResult

class ToggleTorchAction : DeviceAction {
    override val name: String = "toggleTorch"
    override val description: String = "Turns the phone hardware camera flashlight/torch ON or OFF."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val enable = args["enable"] as? Boolean ?: true

        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            if (cameraManager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                    val chars = cameraManager.getCameraCharacteristics(id)
                    chars.get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: cameraManager.cameraIdList.firstOrNull()

                if (cameraId != null) {
                    cameraManager.setTorchMode(cameraId, enable)
                    val stateStr = if (enable) "ON" else "OFF"
                    ActionResult(true, "Flashlight turned $stateStr.", name, mapOf("enabled" to enable))
                } else {
                    ActionResult(false, "No camera flash found on this device.", name)
                }
            } else {
                ActionResult(false, "Flashlight control is not supported on this Android version.", name)
            }
        } catch (e: Exception) {
            ActionResult(false, "Failed to toggle flashlight: ${e.message}", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "enable" to mapOf("type" to "BOOLEAN", "description" to "True to turn torch ON, False to turn OFF")
                ),
                "required" to listOf("enable")
            )
        )
    }
}
