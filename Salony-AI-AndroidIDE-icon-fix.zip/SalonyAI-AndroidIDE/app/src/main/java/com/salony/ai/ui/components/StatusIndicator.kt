package com.salony.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.salony.ai.model.VoiceState
import com.salony.ai.ui.theme.*

@Composable
fun StatusIndicator(
    voiceState: VoiceState,
    modifier: Modifier = Modifier
) {
    val (label, subLabel, badgeColor, borderColor) = when (voiceState) {
        VoiceState.SPEAKING -> Quadruple(
            "Salony is speaking...",
            "Tap orb or speak to interrupt",
            NeonPink.copy(alpha = 0.15f),
            NeonPink.copy(alpha = 0.5f)
        )
        VoiceState.LISTENING -> Quadruple(
            "Listening to you...",
            "Kuch bhi boliye (Hindi, Hinglish, English)",
            NeonCyan.copy(alpha = 0.15f),
            NeonCyan.copy(alpha = 0.5f)
        )
        VoiceState.CONNECTING -> Quadruple(
            "Connecting to Salony...",
            "Establishing real-time Live session",
            NeonPurple.copy(alpha = 0.15f),
            NeonPurple.copy(alpha = 0.5f)
        )
        VoiceState.DISCONNECTED -> Quadruple(
            "Salony is waiting for you",
            "Tap microphone or orb to start",
            SurfaceCard,
            BorderSubtle
        )
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .background(badgeColor, RoundedCornerShape(50.dp))
                .border(1.dp, borderColor, RoundedCornerShape(50.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            Text(
                text = label,
                color = TextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subLabel,
            color = TextMuted,
            fontSize = 11.sp
        )
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
