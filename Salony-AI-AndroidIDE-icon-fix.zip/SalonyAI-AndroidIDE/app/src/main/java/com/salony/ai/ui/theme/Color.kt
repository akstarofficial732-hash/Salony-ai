package com.salony.ai.ui.theme

import androidx.compose.ui.graphics.Color

val DeepBlack = Color(0xFF030014)
val MidnightBackground = Color(0xFF05021A)
val SurfaceCard = Color(0xFF0C0726)
val BorderSubtle = Color(0x33A855F7)

val NeonPurple = Color(0xFFA855F7)
val NeonCyan = Color(0xFF06B6D4)
val NeonPink = Color(0xFFEC4899)
val NeonAmber = Color(0xFFFBBF24)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)
