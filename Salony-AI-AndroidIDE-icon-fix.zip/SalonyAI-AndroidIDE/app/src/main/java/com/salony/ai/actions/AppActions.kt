package com.salony.ai.actions

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.salony.ai.model.ActionResult

class OpenAppAction : DeviceAction {
    override val name: String = "openApp"
    override val description: String = "Opens an installed Android app by name or package, such as YouTube, WhatsApp, Camera, Calculator, Gallery, or Spotify."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val appQuery = (args["app_name"] as? String)?.trim()
            ?: (args["package_name"] as? String)?.trim()
            ?: return ActionResult(false, "App name or package name is required", name)

        val pm = context.packageManager

        // Known direct package shortcuts
        val commonPackages = mapOf(
            "youtube" to "com.google.android.youtube",
            "whatsapp" to "com.whatsapp",
            "camera" to "com.android.camera",
            "chrome" to "com.android.chrome",
            "spotify" to "com.spotify.music",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "calculator" to "com.google.android.calculator",
            "clock" to "com.google.android.deskclock",
            "photos" to "com.google.android.apps.photos"
        )

        val directPkg = commonPackages[appQuery.lowercase()]
        if (directPkg != null) {
            val intent = pm.getLaunchIntentForPackage(directPkg)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return ActionResult(true, "Opened $appQuery successfully", name, mapOf("package" to directPkg))
            }
        }

        // Try direct package launch
        val directIntent = pm.getLaunchIntentForPackage(appQuery)
        if (directIntent != null) {
            directIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(directIntent)
            return ActionResult(true, "Opened $appQuery successfully", name, mapOf("package" to appQuery))
        }

        // Search through installed launcher apps
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveList = pm.queryIntentActivities(mainIntent, 0)
        for (resolveInfo in resolveList) {
            val label = resolveInfo.loadLabel(pm).toString()
            if (label.contains(appQuery, ignoreCase = true) || appQuery.contains(label, ignoreCase = true)) {
                val pkg = resolveInfo.activityInfo.packageName
                val launchIntent = pm.getLaunchIntentForPackage(pkg)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return ActionResult(true, "Opened $label successfully", name, mapOf("package" to pkg, "label" to label))
                }
            }
        }

        return ActionResult(false, "Could not find any installed app matching \"$appQuery\".", name)
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "app_name" to mapOf(
                        "type" to "STRING",
                        "description" to "Name of the app to launch, e.g. YouTube, WhatsApp, Camera, Spotify"
                    ),
                    "package_name" to mapOf(
                        "type" to "STRING",
                        "description" to "Optional exact Android package name, e.g. com.whatsapp"
                    )
                ),
                "required" to listOf("app_name")
            )
        )
    }
}

class OpenWebsiteAction : DeviceAction {
    override val name: String = "openWebsite"
    override val description: String = "Opens a website URL in the user's default browser."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val rawUrl = (args["url"] as? String)?.trim()
            ?: return ActionResult(false, "URL is required", name)

        val uri = try {
            Uri.parse(rawUrl)
        } catch (e: Exception) {
            return ActionResult(false, "Invalid URL format: ${e.message}", name)
        }

        if (uri.scheme != "http" && uri.scheme != "https") {
            return ActionResult(false, "Only HTTP and HTTPS URLs are permitted for security", name)
        }

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            ActionResult(true, "Opened website: ${args["label"] ?: rawUrl}", name, mapOf("url" to rawUrl))
        } catch (e: Exception) {
            ActionResult(false, "Could not open browser: ${e.message}", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "url" to mapOf(
                        "type" to "STRING",
                        "description" to "The full URL starting with http:// or https://"
                    ),
                    "label" to mapOf(
                        "type" to "STRING",
                        "description" to "Optional friendly website name"
                    )
                ),
                "required" to listOf("url")
            )
        )
    }
}
