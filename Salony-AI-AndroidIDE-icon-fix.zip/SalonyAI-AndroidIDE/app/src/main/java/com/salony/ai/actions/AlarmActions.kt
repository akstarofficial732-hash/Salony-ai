package com.salony.ai.actions

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.salony.ai.model.ActionResult

class SetAlarmAction : DeviceAction {
    override val name: String = "setAlarm"
    override val description: String = "Sets an alarm on the Android device for a specific hour and minute."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val hour = (args["hour"] as? Number)?.toInt()
            ?: return ActionResult(false, "Hour (0-23) is required", name)
        val minutes = (args["minutes"] as? Number)?.toInt() ?: 0
        val label = (args["label"] as? String) ?: "Salony Alarm"

        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minutes)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            val timeStr = String.format("%02d:%02d", hour, minutes)
            ActionResult(true, "Alarm set for $timeStr ($label).", name, mapOf("time" to timeStr, "label" to label))
        } catch (e: Exception) {
            ActionResult(false, "Could not set alarm: ${e.message}", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "hour" to mapOf("type" to "INTEGER", "description" to "Hour in 24-hour format (0-23)"),
                    "minutes" to mapOf("type" to "INTEGER", "description" to "Minutes (0-59)"),
                    "label" to mapOf("type" to "STRING", "description" to "Reason or label for the alarm")
                ),
                "required" to listOf("hour")
            )
        )
    }
}

class SetTimerAction : DeviceAction {
    override val name: String = "setTimer"
    override val description: String = "Sets a timer for a given duration in seconds."

    override suspend fun execute(context: Context, args: Map<String, Any?>): ActionResult {
        val seconds = (args["seconds"] as? Number)?.toInt()
            ?: return ActionResult(false, "Duration in seconds is required", name)
        val label = (args["label"] as? String) ?: "Salony Timer"

        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        return try {
            context.startActivity(intent)
            val mins = seconds / 60
            val secs = seconds % 60
            val durationText = if (mins > 0) "$mins min $secs sec" else "$secs seconds"
            ActionResult(true, "Timer set for $durationText ($label).", name, mapOf("seconds" to seconds, "label" to label))
        } catch (e: Exception) {
            ActionResult(false, "Could not set timer: ${e.message}", name)
        }
    }

    override fun getToolDeclaration(): Map<String, Any> {
        return mapOf(
            "name" to name,
            "description" to description,
            "parameters" to mapOf(
                "type" to "OBJECT",
                "properties" to mapOf(
                    "seconds" to mapOf("type" to "INTEGER", "description" to "Timer duration in seconds"),
                    "label" to mapOf("type" to "STRING", "description" to "Timer label")
                ),
                "required" to listOf("seconds")
            )
        )
    }
}
