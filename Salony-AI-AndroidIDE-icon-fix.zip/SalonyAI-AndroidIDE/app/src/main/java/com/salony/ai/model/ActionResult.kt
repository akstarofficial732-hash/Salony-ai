package com.salony.ai.model

data class ActionResult(
    val success: Boolean,
    val message: String,
    val actionName: String,
    val details: Map<String, Any?> = emptyMap(),
    val requiresUserConfirmation: Boolean = false,
    val confirmationPrompt: String? = null
)
