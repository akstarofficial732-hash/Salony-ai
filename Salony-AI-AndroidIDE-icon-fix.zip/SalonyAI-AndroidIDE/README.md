# SALONY AI — Native Android Personal Assistant

SALONY AI is a full-featured native Android personal assistant built with **Kotlin**, **Jetpack Compose**, **Android SDK**, and **Gemini Live API**.

---

## 📱 Features

1. **Continuous Real-Time Voice Conversation (`Gemini Live API`)**:
   - 16 kHz PCM microphone capture via Android `AudioRecord`.
   - 24 kHz gapless PCM playback via Android `AudioTrack`.
   - Real-time interruption handling (instant speech cutoff).
   - Foreground Service (`VoiceAssistantService`) with persistent notification so Salony can listen in the background while you navigate phone apps.
   - Natural Hindi, Hinglish, and English language support.

2. **Modular Android Device Actions**:
   - **Open Installed Apps**: Launch apps by name or package (`openApp`: YouTube, WhatsApp, Camera, Spotify, Calculator, Settings, etc.).
   - **Open Websites**: Validated browser navigation (`openWebsite`).
   - **System Settings**: Wi-Fi, Bluetooth, Display, Sound, Accessibility, and App details (`openSettings`).
   - **Alarms & Timers**: Set alarms and timers directly via `AlarmClock` provider (`setAlarm`, `setTimer`).
   - **Phone & SMS**: Safe dialer launching (`dialPhone`) and message drafting (`sendSms`) with user confirmation.
   - **Flashlight**: Camera hardware torch toggle (`toggleTorch`).
   - **Persistent Personal Memory**: `saveMemory`, `searchMemories`, `listMemories`, `deleteMemory`, `deleteAllMemories`.

3. **User Transparency & Safety**:
   - **Visual Memory Dashboard**: Inspect, search, filter, edit, and delete memories.
   - **Action Audit Log**: Live history of every action executed by Salony with timestamps and success verification.
   - **Consequential Action Confirmations**: Confirmation prompts before placing calls or deleting data.
   - **Optional Accessibility Integration**: Informed consent explanation in settings; never enabled automatically.

---

## 🛠️ How to Open & Build in AndroidIDE

1. **Copy or Transfer the Project**:
   - Copy the `/android` folder to your Android device storage (e.g. `/sdcard/AndroidIDEProjects/SalonyAI`).
2. **Open in AndroidIDE**:
   - Launch **AndroidIDE** on your phone.
   - Tap **Open Project** and navigate to `SalonyAI`.
3. **Sync & Build**:
   - Wait for Gradle sync to complete.
   - Run the **Assemble Debug** task (`./gradlew assembleDebug` or tap the Build button).
   - Install the generated APK on your device.
4. **Permissions**:
   - On first launch, grant **Microphone** permission when prompted.
   - Grant **Notification** permission on Android 13+ to allow the foreground voice service to stay active in the background.

---

## 🌐 Backend & WebSocket Connection

In **Settings > Voice Backend WebSocket URL**:
- For local testing over Wi-Fi: `ws://<YOUR-PC-IP>:3000/live`
- For cloud deployment: `wss://<YOUR-CLOUD-DOMAIN>/live`
- For Android Emulator: `ws://10.0.2.2:3000/live`

The backend bridges speech audio directly to Gemini Live API (`gemini-3.8-live`).

## Important: Real Android phone vs emulator

The default WebSocket URL `ws://10.0.2.2:3000/live` is for an Android emulator, not a physical phone. On a real phone, use the computer's LAN IP address (same Wi-Fi) or a deployed secure `wss://` backend. Building/installing the APK does not itself run the Node backend or provide a Gemini API key. The voice screen may open without a backend, but live Gemini voice cannot connect until a reachable backend is configured in Settings.

For local development only, if connecting to a `ws://` LAN backend is blocked by Android cleartext-traffic policy, use a secure `wss://` endpoint where possible. Avoid shipping a release build with unrestricted cleartext traffic enabled.
